import React from "react";

import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import MapScreen from "./screens/mapscreen";
import BuildingScreen from "./screens/buildingscreens";

const Stack = createStackNavigator();

export default function App() {

  return (

    <NavigationContainer>

      <Stack.Navigator>

        <Stack.Screen
          name="Campus Map"
          component={MapScreen}
        />

        <Stack.Screen
          name="Building"
          component={BuildingScreen}
        />

      </Stack.Navigator>

    </NavigationContainer>

  );

}