import React from "react";
import { View, Text, ScrollView, StyleSheet } from "react-native";

export default function BuildingScreen({ route }) {

const { building } = route.params;

return (

<ScrollView style={styles.container}>

<Text style={styles.title}>
{building.name}
</Text>

<Text style={styles.description}>
{building.description}
</Text>

<Text style={styles.floor}>Ground Floor</Text>

{building.floors.ground.map((room) => (

<Text key={room.id} style={styles.room}>
{room.id} - {room.name}
</Text>

))}

<Text style={styles.floor}>First Floor</Text>

{building.floors.first.map((room) => (

<Text key={room.id} style={styles.room}>
{room.id} - {room.name}
</Text>

))}

</ScrollView>

);

}

const styles = StyleSheet.create({

container:{
padding:20
},

title:{
fontSize:26,
fontWeight:"bold",
marginBottom:10
},

description:{
fontSize:16,
marginBottom:20
},

floor:{
fontSize:18,
fontWeight:"bold",
marginTop:20
},

room:{
fontSize:16,
marginTop:5
}

});