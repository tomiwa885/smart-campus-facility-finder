import React, {useState, UseCallback} from 'react';
import { View, Text, StyleSheet, ScrollView} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Activity, Clock, Heart, Zap } from 'lucide-react-native';


