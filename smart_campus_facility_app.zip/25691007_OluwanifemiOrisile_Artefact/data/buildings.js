const buildings = [

{
id:1,
name:"Technology Hub",
latitude:53.55970,
longitude:-2.87465,
description:"Technology Hub Building",
rooms:[

{ name:"G01", floor:"Ground Floor" },
{ name:"G02", floor:"Ground Floor" },
{ name:"G03", floor:"Ground Floor" },
{ name:"G04", floor:"Ground Floor" },
{ name:"G06A", floor:"Ground Floor" },

{ name:"F01", floor:"First Floor" },
{ name:"F02", floor:"First Floor" },
{ name:"F03", floor:"First Floor" },
{ name:"F05 Games Lab", floor:"First Floor" },
{ name:"F08", floor:"First Floor" },
{ name:"F11", floor:"First Floor" },
{ name:"F12", floor:"First Floor" }

]
},

{
id:2,
name:"Business School",
latitude:53.55878,
longitude:-2.87385,
description:"Business School",
rooms:[

{ name:"B001", floor:"Ground Floor" },
{ name:"B002", floor:"Ground Floor" },
{ name:"B003", floor:"Ground Floor" },
{ name:"B004", floor:"Ground Floor" },
{ name:"B005", floor:"Ground Floor" },

{ name:"B101", floor:"First Floor" },
{ name:"B102", floor:"First Floor" },
{ name:"B103", floor:"First Floor" },
{ name:"B104", floor:"First Floor" },

{ name:"B201", floor:"Second Floor" }

]
},

{
id:3,
name:"Creative Edge",
latitude:53.55910,
longitude:-2.87325,
description:"Creative Edge Building",
rooms:[

{ name:"CE.001", floor:"Ground Floor" },
{ name:"CE.002", floor:"Ground Floor" },
{ name:"CE.003", floor:"Ground Floor" },

{ name:"CE.101", floor:"First Floor" },
{ name:"CE.102", floor:"First Floor" },
{ name:"CE.103", floor:"First Floor" },
{ name:"CE.104", floor:"First Floor" },

{ name:"CE.201", floor:"Second Floor" },
{ name:"CE.202", floor:"Second Floor" },
{ name:"CE.203", floor:"Second Floor" },
{ name:"CE.204", floor:"Second Floor" }

]
},

{
id:4,
name:"Education Building",
latitude:53.55905,
longitude:-2.87260,
description:"Education Department",
rooms:[

{ name:"E1", floor:"Ground Floor" },
{ name:"E2", floor:"Ground Floor" },
{ name:"E3", floor:"Ground Floor" },

{ name:"E10", floor:"First Floor" },
{ name:"E11", floor:"First Floor" },
{ name:"E12", floor:"First Floor" },

{ name:"E20", floor:"Second Floor" },
{ name:"E21", floor:"Second Floor" }

]
},

{
id:5,
name:"Health Building",
latitude:53.55850,
longitude:-2.87245,
description:"Health Sciences Building",
rooms:[

{ name:"H1", floor:"Ground Floor" },
{ name:"H2", floor:"Ground Floor" },

{ name:"H101", floor:"First Floor" },
{ name:"H103", floor:"First Floor" },

{ name:"H201", floor:"Second Floor" },
{ name:"H202", floor:"Second Floor" }

]
},

{
id:6,
name:"Geo Sciences Building",
latitude:53.55935,
longitude:-2.87235,
description:"Geography and Geology",
rooms:[

{ name:"GEO001", floor:"Ground Floor" },
{ name:"GEO002", floor:"Ground Floor" },

{ name:"GEO101", floor:"First Floor" },
{ name:"GEO102", floor:"First Floor" }

]
},

{
id:7,
name:"Wilson Centre",
latitude:53.55892,
longitude:-2.87170,
description:"Sports and Exercise Science Building",
rooms:[

{ name:"W1", floor:"Ground Floor" },
{ name:"W3", floor:"Ground Floor" },

{ name:"W10", floor:"First Floor" },
{ name:"W13", floor:"First Floor" }

]
},

{
id:8,
name:"Catalyst Library",
latitude:53.55942,
longitude:-2.87285,
description:"University Library",
rooms:[

{ name:"Study Area", floor:"Ground Floor" },
{ name:"Computer Area", floor:"First Floor" },
{ name:"Group Study Rooms", floor:"Second Floor" }

]
}

];